# hostname
# hostname:443
sempakterjal.dnsabr.com
tubekedainetgratis.ml
opok.value.cloudns.asia
m.facebook.com.ozip.cf
cara.zzux.com
mywahyoe.ddns.net
sidik.ddns.net
yeopok.ddns.net
lordazazel.sytes.net
xx.yudhy.net
akamaiku.freeddns.org
103.253.27.156.pointdns.pro
103.253.27.43.pointdns.info
118.98.95.106.zxc.yt.pointdns.fun
subscribe.irkmusik.truedns.co
free.facebook.truedns.co
# dhcp-option DNS:9.9.9.9
# dhcp-option DNS:149.112.112.112